'use client'

export default function ShopDetails() {

    return (
        <div className="shop-details">
            <div classname="container">
                <section className="shop-details__main_area ">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-6">
                                <div className="container-banner-activities">
                                    <div className="box-banner-activities border rounded-3 overflow-hidden">
                                        <div className="slick-slider banner-activities-detail slick-initialized" dir="ltr">
                                            {/* normal image */}
                                            <img src="/assets/img/shop-list/img-1.png" alt="Carento" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 ps-lg-4">
                                <div className="shop-details-header">
                                    <div className="d-flex flex-wrap align-items-center gap-4 mb-3">
                                        <div className="shop-details-rate mb-0">
                                            <div className="rate-element">
                                                <span className="rating">4.96
                                                    <span className="reviews"> (672 reviews)</span>
                                                </span>
                                            </div>
                                        </div>
                                        {/* <a className="text-md-medium neutral-500" href="#">SKU
                                            <span className="text-md-bold neutral-1000 ms-1 text-decoration-underline">LVA-4125</span>
                                        </a> */}
                                        <a href="#">
                                            <img src="/assets/img/shop-list/stock.png" alt="Carento" />
                                        </a>
                                    </div>
                                    <div className="shop-details-title-main">
                                        <h5 >Mobil Delvac 1300 Super Heavy Duty <br />Synthetic Blend</h5>
                                    </div>
                                    <div className="shop-details-price">
                                        <span className="text-decoration-line-through"> $68.53 </span>
                                        <h4 className="neutral-1000">$48.25</h4>
                                    </div>
                                    <ul className="shop-details-list">
                                        <li className="text-md-medium neutral-1000">Mobil Delvac 1300 Super Heavy Duty Synthetic Blend</li>
                                        <li className="text-md-medium neutral-1000">Confident driving in all weather conditions</li>
                                        <li className="text-md-medium neutral-1000">Visual Alignment Indicators</li>
                                    </ul>
                                    <div className="shop-details-metas mt-4 border-top pt-4">
                                        <div className="shop-details-meta-left mb-0">
                                            <div className="add-to-cart me-3">
                                                <div className="detail-qty">
                                                    <a className="qty-down ps-2" href="#">
                                                        <svg className="invert" xmlns="http://www.w3.org/2000/svg" width={22} height={22} viewBox="0 0 22 22" fill="none">
                                                            <path d="M15.125 12.375H6.875C6.51033 12.375 6.16059 12.2301 5.90273 11.9723C5.64487 11.7144 5.5 11.3647 5.5 11C5.5 10.6353 5.64487 10.2856 5.90273 10.0277C6.16059 9.76987 6.51033 9.625 6.875 9.625H15.125C15.4897 9.625 15.8394 9.76987 16.0973 10.0277C16.3551 10.2856 16.5 10.6353 16.5 11C16.5 11.3647 16.3551 11.7144 16.0973 11.9723C15.8394 12.2301 15.4897 12.375 15.125 12.375Z" fill="#101010" />
                                                        </svg>
                                                    </a>
                                                    <input className="qty-val w-100px pl-45" value="19" type="text" defaultValue={1} name="quantity" />
                                                    <a className="qty-up pe-2" href="#">
                                                        <svg className="invert" xmlns="http://www.w3.org/2000/svg" width={22} height={22} viewBox="0 0 22 22" fill="none">
                                                            <path d="M15.5833 10.0833H11.9167V6.41667C11.9167 6.17355 11.8201 5.94039 11.6482 5.76849C11.4763 5.59658 11.2431 5.5 11 5.5C10.7569 5.5 10.5237 5.59658 10.3518 5.76849C10.1799 5.94039 10.0833 6.17355 10.0833 6.41667V10.0833H6.41667C6.17355 10.0833 5.94039 10.1799 5.76849 10.3518C5.59658 10.5237 5.5 10.7569 5.5 11C5.5 11.2431 5.59658 11.4763 5.76849 11.6482C5.94039 11.8201 6.17355 11.9167 6.41667 11.9167H10.0833V15.5833C10.0833 15.8264 10.1799 16.0596 10.3518 16.2315C10.5237 16.4034 10.7569 16.5 11 16.5C11.2431 16.5 11.4763 16.4034 11.6482 16.2315C11.8201 16.0596 11.9167 15.8264 11.9167 15.5833V11.9167H15.5833C15.8264 11.9167 16.0596 11.8201 16.2315 11.6482C16.4034 11.4763 16.5 11.2431 16.5 11C16.5 10.7569 16.4034 10.5237 16.2315 10.3518C16.0596 10.1799 15.8264 10.0833 15.5833 10.0833Z" fill="#101010" />
                                                        </svg>
                                                    </a>
                                                </div>
                                            </div>
                                            <button className="shop-details__add_to_cart" >
                                                Add to cart
                                            </button>
                                        </div>
                                        <div className="shop-details-meta-right mb-0 mt-3">
                                            <a className=" btn-share" href="#">
                                                <svg width={16} height={18} viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M13 11.5332C12.012 11.5332 11.1413 12.0193 10.5944 12.7584L5.86633 10.3374C5.94483 10.0698 6 9.79249 6 9.49989C6 9.10302 5.91863 8.72572 5.77807 8.37869L10.7262 5.40109C11.2769 6.04735 12.0863 6.46655 13 6.46655C14.6543 6.46655 16 5.12085 16 3.46655C16 1.81225 14.6543 0.466553 13 0.466553C11.3457 0.466553 10 1.81225 10 3.46655C10 3.84779 10.0785 4.20942 10.2087 4.54515L5.24583 7.53149C4.69563 6.90442 3.8979 6.49989 3 6.49989C1.3457 6.49989 0 7.84559 0 9.49989C0 11.1542 1.3457 12.4999 3 12.4999C4.00433 12.4999 4.8897 11.9996 5.4345 11.2397L10.147 13.6529C10.0602 13.9331 10 14.2249 10 14.5332C10 16.1875 11.3457 17.5332 13 17.5332C14.6543 17.5332 16 16.1875 16 14.5332C16 12.8789 14.6543 11.5332 13 11.5332Z" fill="#101010" />
                                                </svg>
                                                Share
                                            </a>
                                            <a className="btn btn-wishlish" href="/wishlist">
                                                <svg width={20} height={18} viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fillRule="evenodd" clipRule="evenodd" d="M2.2222 2.3638C4.34203 0.243977 7.65342 0.0419426 10.0004 1.7577C12.3473 0.0419426 15.6587 0.243977 17.7786 2.3638C20.1217 4.70695 20.1217 8.50594 17.7786 10.8491L12.1217 16.5059C10.9501 17.6775 9.05063 17.6775 7.87906 16.5059L2.2222 10.8491C-0.120943 8.50594 -0.120943 4.70695 2.2222 2.3638Z" fill="#101010" />
                                                </svg>
                                                Wishlish
                                            </a>
                                        </div>
                                    </div>
                                    <div className="shop-details__description">
                                        <span className="fw-bold">Description :</span>
                                        <span className="text-black">Cleaning Oils, Motor Oils, Oils &amp; Fluids</span>
                                    </div>
                                </div>
                            </div>
                        </div >
                    </div>
                </section>
            </div>
        </div>
    );
}
