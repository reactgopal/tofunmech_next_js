export default function page() {
    return (
        <div>
            <h1>
                Server Error
            </h1>
        </div>
    );
}
