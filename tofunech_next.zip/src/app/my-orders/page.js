export default function MyOrders() {
    return (
        <div>
            <section className="order-history section-padding">
                <div className="container">
                    <div className="order-filters">
                        {/* <h2 className="order-history-title h2">Your Orders</h2> */}
                    </div>
                    <div className="order-list">
                        <div className="order-card_main">
                            {/* Order Header */}
                            <div className="order-header">
                                <span>ORDER PLACED: <b>01/01/2025, 10:30 AM</b></span>
                                <span>TOTAL: ₹1234/-</span>
                                <span>SHIP TO: <b>JOHN DOE</b></span>
                            </div>
                            {/* Order Content */}
                            <div className="second-order-section">
                                <div className="order-content">
                                    <div className="order-details">
                                        <div className="product-item border border-radius-10 mt-1">
                                            {/* Product Image */}
                                            <div className="order-image">
                                                <img src="/assets/img/shop-list/1.webp" alt="product" />
                                            </div>
                                            {/* Product Info */}
                                            <div className="product-info">
                                                <p><strong>Sample Product Name</strong></p>
                                                <p>Price: ₹999/-</p>
                                                <p>Quantity: 2</p>
                                            </div>
                                            {/* Review Button */}
                                            <div className="order-footer mt-auto">
                                                <button className="btn">
                                                    Write a product review
                                                </button>
                                            </div>
                                        </div>
                                        {/* Add more products if needed */}
                                    </div>
                                </div>
                            </div>
                            {/* Order Footer */}
                            <div className="order-footer">
                                <a href="#" target="_blank" rel="noopener noreferrer">
                                    Download Invoice
                                </a>
                            </div>
                        </div>
                        {/* Add more .order-card_main for other orders */}
                    </div>
                </div>
            </section>

        </div>
    );
}
