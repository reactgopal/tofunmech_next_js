'use client';
import { AiOutlineClose } from "react-icons/ai";
import Image from 'next/image';
export default function Cart() {
    const cartItems = [
        {
            id: 1,
            name: "1 SET BRAKE DISCS WITHBRAKE PADS VAG (VW, AUDI, SKODA) 8V0...3021",
            description: "1 set brake discs with brake pads",
            price: 100.0,
            discount: 70.0,
            quantity: 1,
            image: "/assets/img/shop-list/1.webp"
        },
        {
            id: 2,
            name: "1 SET BRAKE DISCS WITHBRAKE PADS VAG (VW, AUDI, SKODA) 8V0...3021",
            description: "1 set brake discs with brake pads",
            price: 250.0,
            quantity: 2,
            image: "/assets/img/shop-list/1.webp"
        }
    ];

    const calculateTotal = () => {
        return cartItems.reduce((total, item) => {
            const finalPrice = item.discount || item.price;
            return total + finalPrice * item.quantity;
        }, 0).toFixed(2);
    };

    return (
        <div className="cart_area">
            <div className="container py-5">
                <div className="table-responsive">
                    <table className="table align-middle text-center">
                        <thead className="table-light">
                            <tr>
                                <th scope="col">PRODUCT</th>
                                <th scope="col">PRICE</th>
                                <th scope="col">QUANTITY</th>
                                <th scope="col">TOTAL</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cartItems.map((item, index) => (
                                <tr key={index}>
                                    {/* Product Name + Image + Remove */}
                                    <td className="text-start d-flex align-items-center gap-3">
                                        <button
                                            className="wishlist_remove"
                                            onClick={() => console.log('Remove', item.id)}
                                        >
                                            <AiOutlineClose size={18} />
                                        </button>
                                        <Image
                                            src={item.image}
                                            alt="product"
                                            width={70}
                                            height={70}
                                            style={{ width: "90px", height: "auto", borderRadius: "5px" }}
                                        />
                                        <div>
                                            <div className="fw-semibold">{item.name}</div>
                                            <small className="text-muted">{item.description}</small>
                                        </div>
                                    </td>

                                    {/* Price */}
                                    <td>
                                        {item.discount ? (
                                            <>
                                                <span className="text-decoration-line-through text-muted me-2">
                                                    €{item.price.toFixed(2)}
                                                </span>
                                                <span className="fw-bold text-success">
                                                    €{item.discount.toFixed(2)}
                                                </span>
                                            </>
                                        ) : (
                                            <span className="fw-bold">€{item.price.toFixed(2)}</span>
                                        )}
                                    </td>

                                    {/* Quantity Controls */}
                                    <td>
                                        <div className="quantity__box justify-content-center">
                                            <button className="quantity__value decrease">-</button>
                                            <h5 className="ms-3 me-3 mt-2">{item.quantity}</h5>
                                            <button className="quantity__value increase">+</button>
                                        </div>
                                    </td>

                                    {/* Action Button */}
                                    <td>
                                        <span className="fw-bold text-success">
                                            €{calculateTotal()}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot >
                            <tr >
                                <td colSpan={3} style={{ fontWeight: "600", textAlign: "left" }}>
                                    <p>SubTotal:</p>
                                    <p>Estimated delivery costs:</p>
                                    <p>Total:</p>
                                </td>
                                <td className="text-center">
                                    <p>₹ 110/-</p>
                                    <p>Free</p>
                                    <p>₹ {calculateTotal()}</p>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    <div className="d-flex justify-content-between">
                        <button className="btn__view_estimate">View Estimate</button>
                        <button className="btn__cart" >Proceed to Checkout</button>
                    </div>
                </div>
            </div>
        </div>
    );
}
